/* ==========================================================================
   ALEX RIVERS | MECHANICAL DESIGNER PORTFOLIO JAVASCRIPT LOGIC
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ------------------------------------------------------------------------
   * 1. Mobile Menu Toggle
   * ------------------------------------------------------------------------ */
  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      const isExpanded = navMenu.classList.contains('active');
      menuToggle.setAttribute('aria-expanded', isExpanded);
    });

    // Close menu when clicking on a navigation link
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
      });
    });
  }

  /* ------------------------------------------------------------------------
   * 2. Active Navigation Section Highlighting (IntersectionObserver)
   * ------------------------------------------------------------------------ */
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -70% 0px',
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(section => observer.observe(section));

  /* ------------------------------------------------------------------------
   * 3. Projects Category Filter
   * ------------------------------------------------------------------------ */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Update active button state
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (filterValue === 'all' || filterValue === cardCategory) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'scale(0.95)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 300);
        }
      });
    });
  });

  /* ------------------------------------------------------------------------
   * 4. Project Engineering Details Modal (<dialog>)
   * ------------------------------------------------------------------------ */
  const projectData = {
    'char-save': {
      title: 'CHAR SAVE High-Efficiency Biomass Stove',
      category: 'Thermal & Appliance Design',
      image: 'assets/char_save_cookstove.jpg',
      overview: 'High-efficiency biomass cookstove featuring a powder-coated sheet metal outer shell, refractory combustion chamber liner, glowing ember bed visualization, heavy-duty cast iron pot supports, and an ergonomic sliding air damper knob for precise thermal combustion control.',
      specs: [
        '<strong>CAD Software:</strong> SolidWorks 2024 (Sheet Metal & Weldments)',
        '<strong>Combustion Airflow:</strong> Front Damper Sliding Control Mechanism',
        '<strong>Outer Housing:</strong> 1.5mm Cold Rolled Steel (Heat-Resistant Powder Coat)',
        '<strong>Pot Supports:</strong> Cast Iron 4-Prong Ribbed Grate',
        '<strong>Thermal Efficiency:</strong> 45% Fuel Savings vs open fire cooking'
      ],
      dfmTags: [
        'Sheet Metal DXF',
        'Thermal Combustion DFM',
        'Powder Coat Finish',
        'Laser Cut Steel',
        'Airflow Damper Knob'
      ]
    },
    'solar-kiosk': {
      title: 'ADDIS ABABA Smart Solar Kiosk & Recycling Unit',
      category: 'Sheet Metal & Kiosks',
      image: 'assets/solar_kiosk_recycle.jpg',
      overview: 'Multi-functional smart city infrastructure unit incorporating a top solar canopy, integrated LED digital clock/date display, high-visibility digital outdoor display screen, and dual recycling/waste compartments with lockable access doors.',
      specs: [
        '<strong>CAD Software:</strong> SolidWorks 2024 (Large Assembly Structure)',
        '<strong>Structure:</strong> 2.0mm Laser-Cut Powder-Coated Steel Chassis',
        '<strong>Weather Resistance:</strong> IP65 Rated Rubber Gasket Enclosure Seals',
        '<strong>Access Hardware:</strong> Stainless Steel Hinges & PEM Cam Locks',
        '<strong>Power System:</strong> Top Solar Panel Canopy Bracket Routing'
      ],
      dfmTags: [
        'Outdoor Kiosk DFM',
        'Laser Cut DXF',
        'PEM Self-Clinching Hardware',
        'IP65 Weatherproofing',
        'Solar Panel Canopy'
      ]
    },
    'met-fab': {
      title: 'MET-FAB Biomass Cookstove CAD & Ash Drawer',
      category: 'Thermal & Internal Mechanisms',
      image: 'assets/cookstove_drawer_cad.jpg',
      overview: 'Full transparent CAD assembly study demonstrating internal perforated combustion grate, internal sheet metal wall clearances, rivet/spot-weld locations, and an extendable ash collector drawer for easy cleaning.',
      specs: [
        '<strong>CAD Study:</strong> Transparent Shell Clearance & Motion Audit',
        '<strong>Internal Liner:</strong> Perforated Steel Grate for Airflow Distribution',
        '<strong>Ash Drawer:</strong> Sliding Rail Sheet Metal Tray Mechanism',
        '<strong>Assembly Method:</strong> Spot Welding & Stainless Rivet Fasteners',
        '<strong>DFM Optimization:</strong> Zero-binding drawer slide tolerances'
      ],
      dfmTags: [
        'CAD Wireframe Audit',
        'Sliding Drawer Mechanism',
        'Perforated Sheet Metal',
        'Fastener Clearance',
        'Rivet Layout'
      ]
    },
    'mcb-breaker': {
      title: 'CHNT C32 Miniature Circuit Breaker (MCB)',
      category: 'Electrical Hardware',
      image: 'assets/mcb_circuit_breaker.jpg',
      overview: 'High-precision injection-molded plastic enclosure for DIN-rail miniature circuit breaker. Designed with internal arc chute channels, silver contact trip mechanism seats, terminal screw bosses, and a spring-loaded 35mm DIN-rail latch.',
      specs: [
        '<strong>CAD Software:</strong> SolidWorks Surface & Mold Design Toolset',
        '<strong>Material:</strong> Flame-Retardant Polyamide (PA66-GF25)',
        '<strong>Mounting Standard:</strong> 35mm DIN-Rail (EN 50022 Standard)',
        '<strong>Mechanism:</strong> Thermal-Magnetic Trip Lever & Arc Chute',
        '<strong>Production Method:</strong> Plastic Injection Molding (Multi-Cavity)'
      ],
      dfmTags: [
        'Injection Molding DFM',
        'PA66 Flame Retardant',
        'Snap-Fit DIN Latch',
        'Arc Chute Assembly',
        'Draft Angle Analysis'
      ]
    }
  };

  const dialog = document.getElementById('project-modal');
  const modalCloseBtn = document.getElementById('modal-close');
  const modalCloseBtnBottom = document.getElementById('modal-close-btn');

  const modalCategory = document.getElementById('modal-category');
  const modalTitle = document.getElementById('modal-title');
  const modalImg = document.getElementById('modal-img');
  const modalOverview = document.getElementById('modal-overview');
  const modalSpecs = document.getElementById('modal-specs');
  const modalDfm = document.getElementById('modal-dfm');

  document.querySelectorAll('.view-project-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const projectId = btn.getAttribute('data-project');
      const data = projectData[projectId];

      if (data && dialog) {
        modalCategory.textContent = data.category;
        modalTitle.textContent = data.title;
        modalImg.src = data.image;
        modalOverview.textContent = data.overview;

        // Populate Specs List
        modalSpecs.innerHTML = data.specs.map(spec => `<li>${spec}</li>`).join('');

        // Populate DFM Tags
        modalDfm.innerHTML = data.dfmTags.map(tag => `<span class="tag">${tag}</span>`).join('');

        dialog.showModal();
      }
    });
  });

  const closeModal = () => {
    if (dialog) dialog.close();
  };

  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);
  if (modalCloseBtnBottom) modalCloseBtnBottom.addEventListener('click', closeModal);

  // Close when clicking outside dialog window
  if (dialog) {
    dialog.addEventListener('click', (e) => {
      const rect = dialog.getBoundingClientRect();
      const isInDialog = (rect.top <= e.clientY && e.clientY <= rect.top + rect.height &&
        rect.left <= e.clientX && e.clientX <= rect.left + rect.width);
      if (!isInDialog) {
        dialog.close();
      }
    });
  }

  /* ------------------------------------------------------------------------
   * 5. Interactive Contact Form Validation & Toast Notification
   * ------------------------------------------------------------------------ */
  const contactForm = document.getElementById('contact-form');
  const submitBtn = document.getElementById('submit-btn');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      let isValid = true;

      const nameInput = document.getElementById('name');
      const emailInput = document.getElementById('email');
      const messageInput = document.getElementById('message');

      // Helper validation functions
      const validateInput = (input, condition) => {
        const group = input.closest('.form-group');
        if (!condition) {
          group.classList.add('has-error');
          isValid = false;
        } else {
          group.classList.remove('has-error');
        }
      };

      validateInput(nameInput, nameInput.value.trim().length > 1);
      
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      validateInput(emailInput, emailRegex.test(emailInput.value.trim()));
      
      validateInput(messageInput, messageInput.value.trim().length > 5);

      if (isValid) {
        // Change button state
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>
          <span>Sending Engineering Specs...</span>
        `;

        setTimeout(() => {
          showToast('Message sent successfully! Alex Rivers will review your mechanical requirements shortly.');
          contactForm.reset();
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
        }, 1200);
      }
    });
  }

  /* ------------------------------------------------------------------------
   * 6. Toast Notification Helper
   * ------------------------------------------------------------------------ */
  function showToast(message) {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0d9488" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      <span>${message}</span>
    `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

});
